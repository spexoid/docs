<script>
	import { onMount } from 'svelte'
	import { password, status } from '@store/global'

	let screenVisible = 0

	function login() {
		let pass = $password
		console.log('existing password : ', pass)
		if (pass == '0') {
			console.log(pass)
			pass = prompt('Master Password')
		}
		fetch('/api/login', {
			method: 'POST',
			headers: {
				'content-type': 'application/json'
			},
			body: JSON.stringify({ password: pass })
		})
			.then(res => res.json())
			.then(data => {
				if (data.status === 'success') {
					console.log('login successful')
					password.set(pass)
					screenVisible = 1
					refresh()
				} else {
					alert('Invalid password')
					console.log('login unsuccessfull')
					screenVisible = 0
					password.set(0)
					login()
				}
			})
	}

	// Sidebar and App functions
	let fs = 0
	function fullscreen() {
		if (!document.fullscreenElement) {
			document.body.requestFullscreen()
			fs = 1
		} else {
			document.exitFullscreen()
			fs = 0
		}
	}

	function logout() {
		localStorage.clear()
		location.reload()
	}

	let interval = []
	function emptyInterval() {
		interval.forEach(i => {
			clearInterval(i)
		})
	}

	// Screen Management
	let screen = {
		list: [
			{
				name: 'home',
				active: 1,
				icon: ` <path stroke-linecap="round" stroke-linejoin="round" d="M2.25 12l8.954-8.955c.44-.439 1.152-.439 1.591 0L21.75 12M4.5 9.75v10.125c0 .621.504 1.125 1.125 1.125H9.75v-4.875c0-.621.504-1.125 1.125-1.125h2.25c.621 0 1.125.504 1.125 1.125V21h4.125c.621 0 1.125-.504 1.125-1.125V9.75M8.25 21h8.25"></path>`
			},
			{
				name: 'wallet',
				active: 0,
				icon: `<path d="M21 9C21 8.40326 20.7629 7.83097 20.341 7.40901C19.919 6.98705 19.3467 6.75 18.75 6.75H15C15 7.54565 14.6839 8.30871 14.1213 8.87132C13.5587 9.43393 12.7956 9.75 12 9.75C11.2044 9.75 10.4413 9.43393 9.87868 8.87132C9.31607 8.30871 9 7.54565 9 6.75H5.25C4.65326 6.75 4.08097 6.98705 3.65901 7.40901C3.23705 7.83097 3 8.40326 3 9M21 9V18C21 18.5967 20.7629 19.169 20.341 19.591C19.919 20.0129 19.3467 20.25 18.75 20.25H5.25C4.65326 20.25 4.08097 20.0129 3.65901 19.591C3.23705 19.169 3 18.5967 3 18V9M21 9V6C21 5.40326 20.7629 4.83097 20.341 4.40901C19.919 3.98705 19.3467 3.75 18.75 3.75H5.25C4.65326 3.75 4.08097 3.98705 3.65901 4.40901C3.23705 4.83097 3 5.40326 3 6V9" stroke-linecap="round" stroke-linejoin="round"/> <path d="M15 12L9 18M9 18H13.5M9 18V13.5"stroke-linecap="round" stroke-linejoin="round"/>`
			},
			{
				name: 'withdraw',
				active: 0,
				icon: `<path d="M21 9C21 8.40326 20.7629 7.83097 20.341 7.40901C19.919 6.98705 19.3467 6.75 18.75 6.75H15C15 7.54565 14.6839 8.30871 14.1213 8.87132C13.5587 9.43393 12.7956 9.75 12 9.75C11.2044 9.75 10.4413 9.43393 9.87868 8.87132C9.31607 8.30871 9 7.54565 9 6.75H5.25C4.65326 6.75 4.08097 6.98705 3.65901 7.40901C3.23705 7.83097 3 8.40326 3 9M21 9V18C21 18.5967 20.7629 19.169 20.341 19.591C19.919 20.0129 19.3467 20.25 18.75 20.25H5.25C4.65326 20.25 4.08097 20.0129 3.65901 19.591C3.23705 19.169 3 18.5967 3 18V9M21 9V6C21 5.40326 20.7629 4.83097 20.341 4.40901C19.919 3.98705 19.3467 3.75 18.75 3.75H5.25C4.65326 3.75 4.08097 3.98705 3.65901 4.40901C3.23705 4.83097 3 5.40326 3 6V9" stroke-linecap="round" stroke-linejoin="round"/><path d="M9 18L15 12M15 12H10.5M15 12V16.5" stroke-linejoin="round"/>`
			},
			{
				name: 'user',
				active: 0,
				icon: `<path stroke-linecap="round" stroke-linejoin="round" d="M18 18.72a9.094 9.094 0 003.741-.479 3 3 0 00-4.682-2.72m.94 3.198l.001.031c0 .225-.012.447-.037.666A11.944 11.944 0 0112 21c-2.17 0-4.207-.576-5.963-1.584A6.062 6.062 0 016 18.719m12 0a5.971 5.971 0 00-.941-3.197m0 0A5.995 5.995 0 0012 12.75a5.995 5.995 0 00-5.058 2.772m0 0a3 3 0 00-4.681 2.72 8.986 8.986 0 003.74.477m.94-3.197a5.971 5.971 0 00-.94 3.197M15 6.75a3 3 0 11-6 0 3 3 0 016 0zm6 3a2.25 2.25 0 11-4.5 0 2.25 2.25 0 014.5 0zm-13.5 0a2.25 2.25 0 11-4.5 0 2.25 2.25 0 014.5 0z"></path>`
			},
			{
				name: 'game',
				active: 0,
				icon: `<path stroke-linecap="round" stroke-linejoin="round" d="M14.25 6.087c0-.355.186-.676.401-.959.221-.29.349-.634.349-1.003 0-1.036-1.007-1.875-2.25-1.875s-2.25.84-2.25 1.875c0 .369.128.713.349 1.003.215.283.401.604.401.959v0a.64.64 0 01-.657.643 48.39 48.39 0 01-4.163-.3c.186 1.613.293 3.25.315 4.907a.656.656 0 01-.658.663v0c-.355 0-.676-.186-.959-.401a1.647 1.647 0 00-1.003-.349c-1.036 0-1.875 1.007-1.875 2.25s.84 2.25 1.875 2.25c.369 0 .713-.128 1.003-.349.283-.215.604-.401.959-.401v0c.31 0 .555.26.532.57a48.039 48.039 0 01-.642 5.056c1.518.19 3.058.309 4.616.354a.64.64 0 00.657-.643v0c0-.355-.186-.676-.401-.959a1.647 1.647 0 01-.349-1.003c0-1.035 1.008-1.875 2.25-1.875 1.243 0 2.25.84 2.25 1.875 0 .369-.128.713-.349 1.003-.215.283-.4.604-.4.959v0c0 .333.277.599.61.58a48.1 48.1 0 005.427-.63 48.05 48.05 0 00.582-4.717.532.532 0 00-.533-.57v0c-.355 0-.676.186-.959.401-.29.221-.634.349-1.003.349-1.035 0-1.875-1.007-1.875-2.25s.84-2.25 1.875-2.25c.37 0 .713.128 1.003.349.283.215.604.401.96.401v0a.656.656 0 00.658-.663 48.422 48.422 0 00-.37-5.36c-1.886.342-3.81.574-5.766.689a.578.578 0 01-.61-.58v0z"></path>`
			}
		],
		switch(name) {
			emptyInterval()
			screen.list.forEach((s, i) => {
				screen.list[i].active = s.name === name ? 1 : 0
			})
			this.callback[name]()
		},
		callback: {
			home: e => {
				console.log('home')
				screen.callback.user()
				screen.callback.withdraw()
				screen.callback.wallet()
				screen.callback.game()
			},
			wallet: e => {
				console.log('wallet')
				fetch('/api/wallet', {
					method: 'POST',
					headers: {
						'content-type': 'application/json'
					},
					body: JSON.stringify({ password: $password })
				})
					.then(res => res.json())
					.then(data => {
						rechargeList = data.rechargeList
						rechargeAmount = 0
					})
			},
			withdraw: e => {
				console.log('withdraw')
				fetch('/api/withdraw', {
					method: 'POST',
					headers: {
						'content-type': 'application/json'
					},
					body: JSON.stringify({ password: $password })
				})
					.then(res => res.json())
					.then(data => {
						withdrawList = data.withdrawList
						withdrawRequest = 0
						withdrawAmount = 0
					})
			},
			user: e => {
				console.log('user')
				fetch('/api/user', {
					method: 'POST',
					headers: {
						'content-type': 'application/json'
					},
					body: JSON.stringify({ password: $password })
				})
					.then(res => res.json())
					.then(data => {
						userList = data.userList
						cash = 0
						credit = 0
					})
			},
			game: e => {
				console.log('game')
				function refreshGameData() {
					fetch('/api/game', {
						method: 'POST',
						headers: {
							'content-type': 'application/json'
						},
						body: JSON.stringify({ password: $password })
					})
						.then(res => res.json())
						.then(data => {
							gameData = data
						})
				}
				refreshGameData()
				let gameInterval = setInterval(e => {
					refreshGameData()
				}, 500)
				interval.push(gameInterval)
			}
		}
	}
	$: as = screen.list.filter(s => s.active)[0].name

	function forceWinner(slot) {
		fetch('/api/forcewinner', {
			method: 'POST',
			headers: {
				'content-type': 'application/json'
			},
			body: JSON.stringify({ password: $password, forcewinner: slot })
		})
			.then(res => res.json())
			.then(data => {
				console.log(data)
			})
	}

	let rechargeForm

	function recharge() {
		let fd = Object.fromEntries(new FormData(rechargeForm))
		fetch('/api/recharge', {
			method: 'POST',
			headers: {
				'content-type': 'application/json'
			},
			body: JSON.stringify({ password: $password, ...fd })
		})
			.then(res => res.json())
			.then(data => {
				alert(data.msg)
				refresh()
				rechargeForm.reset()
			})
	}

	function approve(approveId) {
		fetch('/api/approve', {
			method: 'POST',
			headers: {
				'content-type': 'application/json'
			},
			body: JSON.stringify({ password: $password, approveId })
		})
			.then(res => res.json())
			.then(data => {
				refresh()
			})
	}

	// Withdraw Table
	let withdrawList = []
	let withdrawRequest = 0
	let withdrawAmount = 0
	$: withdrawList.forEach(w => {
		w.status === 'pending' && withdrawRequest++
		withdrawAmount += w.amount * 0.95
	})

	let rechargeList = []
	let rechargeAmount = 0
	$: rechargeList.forEach(r => {
		rechargeAmount += r.amount
	})

	// User List
	let userList = []
	let cash = 0
	let credit = 0
	$: total = cash + credit
	$: userList.forEach(u => {
		if (![98, 1, 2].includes(u.id)) {
			cash += u.cash
			credit += u.credit
		}
	})

	// Game Data
	let gameData = {
		id: 0,
		totalin: 0,
		started: 0,
		timestamp: 0,
		forcewinner: 0,
		winner: 0,
		percentage: 0,
		timeLeft: 0,
		bets: [0, 0, 0, 0, 0, 0, 0, 0, 0],
		games: []
	}
	let slots = ['blue', 'yellow', 'red', 'blue', 'yellow', 'red', 'blue', 'yellow', 'red']

	function refresh() {
		screen.switch(as)
	}
	onMount(e => {
		login()
	})
</script>

{#if screenVisible}
	<div class="flex h-screen w-full">
		<!-- sidebar -->
		<aside class="flex h-screen w-fit flex-col justify-between bg-slate-900 p-2">
			<div class="flex flex-col gap-2">
				{#each screen.list as s}
					<button
						on:click={e => {
							screen.switch(s.name)
						}}
						class="h-12 w-12 rounded bg-slate-800 p-2 transition-all hover:bg-slate-700 {s.active
							? 'text-amber-300 ring-2 ring-amber-300'
							: 'text-slate-300'}"
					>
						<svg fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24">
							{@html s.icon}
						</svg>
					</button>
				{/each}
			</div>
			<div class="flex flex-col gap-2">
				<button
					on:click={fullscreen}
					class="h-12 w-12 rounded bg-slate-800 p-2 text-lg text-slate-300"
				>
					{#if !fs}
						<svg fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24">
							<path
								stroke-linecap="round"
								stroke-linejoin="round"
								d="M3.75 3.75v4.5m0-4.5h4.5m-4.5 0L9 9M3.75 20.25v-4.5m0 4.5h4.5m-4.5 0L9 15M20.25 3.75h-4.5m4.5 0v4.5m0-4.5L15 9m5.25 11.25h-4.5m4.5 0v-4.5m0 4.5L15 15"
							/>
						</svg>
					{:else}
						<svg fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24">
							<path
								stroke-linecap="round"
								stroke-linejoin="round"
								d="M9 9V4.5M9 9H4.5M9 9L3.75 3.75M9 15v4.5M9 15H4.5M9 15l-5.25 5.25M15 9h4.5M15 9V4.5M15 9l5.25-5.25M15 15h4.5M15 15v4.5m0-4.5l5.25 5.25"
							/>
						</svg>
					{/if}
				</button>
				<button on:click={logout} class="h-12 w-12 rounded bg-slate-800 p-2 text-lg text-slate-300">
					<svg fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24">
						<path
							stroke-linecap="round"
							stroke-linejoin="round"
							d="M15.75 9V5.25A2.25 2.25 0 0013.5 3h-6a2.25 2.25 0 00-2.25 2.25v13.5A2.25 2.25 0 007.5 21h6a2.25 2.25 0 002.25-2.25V15m3 0l3-3m0 0l-3-3m3 3H9"
						/>
					</svg>
				</button>
			</div>
		</aside>
		<main class="flex flex-1 flex-col">
			<!-- topbar -->
			<div class="sticky top-0 block bg-slate-900 p-2">
				<div class="flex h-12 items-center justify-between">
					<span class="font-semibold">RAFTAAR</span>
					<span class="font-semibold">{as.toUpperCase()}</span>
					<button
						on:click={refresh}
						class="flex h-12 w-12 items-center justify-center rounded bg-amber-300 p-3 text-slate-900"
					>
						<svg fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24">
							<path
								stroke-linecap="round"
								stroke-linejoin="round"
								d="M16.023 9.348h4.992v-.001M2.985 19.644v-4.992m0 0h4.992m-4.993 0l3.181 3.183a8.25 8.25 0 0013.803-3.7M4.031 9.865a8.25 8.25 0 0113.803-3.7l3.181 3.182m0-4.991v4.99"
							/>
						</svg>
					</button>
				</div>
			</div>
			<div class="flex h-full flex-col items-center overflow-y-auto bg-slate-800 p-4">
				<!-- HOME SCREEN -->
				<div class="{as === 'home' ? 'flex' : 'hidden'} w-full max-w-4xl flex-col gap-4">
					<div class="flex w-full flex-wrap gap-4 font-bold">
						<div
							class="flex min-w-[196px] flex-1 flex-col items-center gap-4 rounded bg-slate-900 p-4"
						>
							<p class="w-full">USERS</p>
							<h1 class="text-7xl font-thin text-amber-200">{userList.length}</h1>
						</div>
						<div
							class="flex min-w-[196px] flex-1 flex-col items-center gap-4 rounded bg-slate-900 p-4"
						>
							<p class="w-full">WITHDRAWAL</p>
							<h1 class="text-7xl font-thin text-amber-200">
								{withdrawRequest}
							</h1>
						</div>
						<div
							class="flex min-w-[196px] flex-1 flex-col items-center gap-4 rounded bg-slate-900 p-4"
						>
							<p class="w-full">P&L STATUS</p>
							<h1 class="text-7xl font-thin text-amber-200">{gameData.percentage}%</h1>
						</div>
						<div class="flex w-full justify-between gap-4 rounded bg-slate-900 p-4">
							<p><span class="text-amber-300">IN : </span> {rechargeAmount}</p>
							<p><span class="text-amber-300">OUT : </span> {withdrawAmount}</p>
							<p><span class="text-amber-300">P&L : </span> {rechargeAmount - withdrawAmount}</p>
						</div>
						<div class="flex w-full justify-between gap-4 rounded bg-slate-900 p-4">
							<p><span class="text-amber-300">CASH : </span> {cash}</p>
							<p><span class="text-amber-300">CREDIT : </span> {credit}</p>
							<p><span class="text-amber-300">TOTAL : </span> {total}</p>
						</div>
					</div>
				</div>
				<!-- WALLET SCREEN -->
				<div class="{as === 'wallet' ? 'flex' : 'hidden'} w-full max-w-4xl flex-col gap-4">
					<form
						bind:this={rechargeForm}
						on:submit|preventDefault={recharge}
						class="flex flex-wrap gap-4 rounded bg-slate-900 p-4"
					>
						<p class="w-full font-bold">Recharge</p>
						<div class="relative w-full min-w-[262px] flex-1">
							<label
								class="absolute flex h-12 w-12 items-center justify-center rounded-l bg-slate-800 p-3"
								for="mobile"
							>
								<svg fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24">
									<path
										stroke-linecap="round"
										stroke-linejoin="round"
										d="M10.5 1.5H8.25A2.25 2.25 0 006 3.75v16.5a2.25 2.25 0 002.25 2.25h7.5A2.25 2.25 0 0018 20.25V3.75a2.25 2.25 0 00-2.25-2.25H13.5m-3 0V3h3V1.5m-3 0h3m-3 18.75h3"
									/>
								</svg>
							</label>
							<input
								id="mobile"
								name="mobile"
								type="number"
								class="h-12 w-full rounded bg-slate-700 pl-16 pr-4 font-medium text-slate-200 outline-0 ring-amber-300 transition-all focus:ring-2"
								placeholder="Mobile no."
								required
							/>
						</div>
						<div class="relative w-full min-w-[262px] flex-1">
							<label
								class="absolute flex h-12 w-12 items-center justify-center rounded-l bg-slate-800 p-3"
								for="amount"
							>
								<svg fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24">
									<path
										stroke-linecap="round"
										stroke-linejoin="round"
										d="M12 6v12m-3-2.818l.879.659c1.171.879 3.07.879 4.242 0 1.172-.879 1.172-2.303 0-3.182C13.536 12.219 12.768 12 12 12c-.725 0-1.45-.22-2.003-.659-1.106-.879-1.106-2.303 0-3.182s2.9-.879 4.006 0l.415.33M21 12a9 9 0 11-18 0 9 9 0 0118 0z"
									/>
								</svg>
							</label>
							<input
								type="number"
								id="amount"
								name="amount"
								step="100"
								class="h-12 w-full rounded bg-slate-700 pl-16 pr-4 font-medium text-slate-200 outline-0 ring-amber-300 transition-all focus:ring-2"
								placeholder="Amount"
								required
							/>
						</div>
						<button
							class="flex h-12 flex-1 items-center justify-center rounded bg-amber-300 px-4 font-bold text-slate-900"
						>
							RECHARGE
						</button>
					</form>
					<div class="flex flex-col gap-4 rounded bg-slate-900 p-4">
						<div class="flex justify-between font-bold">
							<p class="font-bold">Recharge History</p>
							<p class="font-bold">TOTAL : <span class="text-amber-300">{rechargeAmount}</span></p>
						</div>
						{#if rechargeList.length}
							<div class="w-full overflow-x-auto rounded">
								<table class="w-full">
									<colgroup>
										<col />
										<col />
										<col />
									</colgroup>
									<tr class="bg-amber-300 text-left text-slate-900">
										<th>Time</th>
										<th>Mobile</th>
										<th>Amount</th>
									</tr>
									{#each rechargeList as r, i}
										<tr class={i % 2 == 0 ? 'bg-slate-800' : ''}>
											<td>{new Date(r.timestamp * 1000).toLocaleString('hi-IN')}</td>
											<td>{r.mobile}</td>
											<td>{r.amount}</td>
										</tr>
									{/each}
								</table>
							</div>
						{/if}
					</div>
				</div>
				<!-- WITHDRAW SCREEN -->
				<div class="{as === 'withdraw' ? 'flex' : 'hidden'} w-full max-w-4xl flex-col gap-4">
					<div class="flex flex-col gap-4 rounded bg-slate-900 p-4">
						<div class="flex justify-between font-bold">
							<p class="font-bold">
								Withdraw Requests : <span class="text-amber-300">{withdrawRequest}</span>
							</p>
							<p class="font-bold">TOTAL : <span class="text-amber-300">{withdrawAmount}</span></p>
						</div>

						{#if withdrawList.length}
							<div class="w-full overflow-x-auto rounded">
								<table class="w-full">
									<colgroup>
										<col />
										<col />
										<col />
										<col />
										<col />
										<col class="w-[90px]" />
									</colgroup>
									<tr class="bg-amber-300 text-left text-slate-900">
										<th>ID</th>
										<th>Mobile</th>
										<th>UPI ID</th>
										<th>Amount</th>
										<th>Final Amount</th>
										<th>Status</th>
									</tr>
									{#each withdrawList as w, i}
										<tr class={i % 2 == 0 ? 'bg-slate-800' : ''}>
											<td>{w.id}</td>
											<td>{w.mobile}</td>
											<td>{w.upiid}</td>
											<td>{w.amount}</td>
											<td>{w.amount * 0.95}</td>
											<td class="min-w-[90px]">
												{#if w.status === 'completed'}
													<p>completed</p>
												{:else}<button
														on:click={e => {
															approve(w.id)
														}}
														class=" float-left mr-2 inline-flex h-8 w-8 items-center justify-center rounded bg-green-500 p-1 text-white"
													>
														<svg
															fill="none"
															stroke="currentColor"
															stroke-width="1.5"
															viewBox="0 0 24 24"
														>
															<path
																stroke-linecap="round"
																stroke-linejoin="round"
																d="M9 12.75L11.25 15 15 9.75M21 12a9 9 0 11-18 0 9 9 0 0118 0z"
															/>
														</svg>
													</button>
												{/if}
											</td>
										</tr>
									{/each}
								</table>
							</div>
						{/if}
					</div>
				</div>
				<!-- USER SCREEN -->
				<div class="{as === 'user' ? 'flex' : 'hidden'} w-full max-w-4xl flex-col gap-4">
					<div class="flex flex-col gap-4 rounded bg-slate-900 p-4">
						<div class="flex justify-between font-bold">
							<p class="font-bold">
								Users : <span class="text-amber-300">{userList.length}</span>
							</p>
							<p class="font-bold">CASH : <span class="text-amber-300">{cash}</span></p>
							<p class="font-bold">CREDIT : <span class="text-amber-300">{credit}</span></p>
							<p class="font-bold">TOTAL : <span class="text-amber-300">{total}</span></p>
						</div>

						<div class="w-full overflow-x-auto rounded">
							<table class="w-full">
								<tr class="bg-amber-300 text-left text-slate-900">
									<th>ID</th>
									<th>Name</th>
									<th>Mobile</th>
									<th>Ref</th>
									<th>Cash</th>
									<th>Credit</th>
									<th>TOTAL</th>
									<th>login</th>
									<th>recharge</th>
								</tr>
								{#each userList as u, i}
									<tr
										class="{i % 2 == 0 ? 'bg-slate-800' : ''} {u.firstrecharge === 'no'
											? 'text-slate-400'
											: ''}"
									>
										<td>{u.id}</td>
										<td>{u.name}</td>
										<td>{u.mobile}</td>
										<td>{u.ref}</td>
										<td>{u.cash}</td>
										<td>{u.credit}</td>
										<td>{u.cash + u.credit}</td>
										<td
											><div
												class="mx-auto h-4 w-4 rounded-full {u.token
													? 'bg-green-500'
													: 'bg-red-500'}"
											/></td
										>
										<td>
											<div
												class="mx-auto h-4 w-4 rounded-full {u.firstrecharge == 'yes'
													? 'bg-green-500'
													: 'bg-red-500'}"
											/>
										</td>
									</tr>
								{/each}
							</table>
						</div>
					</div>
				</div>
				<!-- GAME SCREEN -->
				<div class="{as === 'game' ? 'flex' : 'hidden'} w-full max-w-4xl flex-col gap-4">
					<div class="flex flex-col gap-4 rounded bg-slate-900 p-4">
						<div class="flex justify-between font-bold">
							<p>G : <span class="text-amber-300">{gameData.id}</span></p>
							<p>IN : <span class="text-amber-300">{gameData.totalin}</span></p>
							<p>W : <span class="text-amber-300">{gameData.winner}</span></p>
							<p>P : <span class="text-amber-300">{gameData.percentage}</span></p>
							<p>
								T : <span class="inline-block w-8 text-right text-amber-300"
									>{gameData.timeLeft}</span
								>
							</p>
						</div>
						<div class="w-full overflow-x-auto rounded">
							<table class="w-full">
								<tr class="bg-amber-300 text-left text-slate-900">
									<th>Slot</th>
									<th>Force</th>
									<th>Out</th>
								</tr>
								{#each gameData.bets as b, i}
									<tr class={i % 2 == 0 ? 'bg-slate-800' : ''}>
										<td class="text-center font-bold">{i + 1}</td>
										<td>
											<a
												on:click|preventDefault={e => {
													forceWinner(i + 1)
												}}
												href="#!"
												class="mx-auto flex h-6 w-6 items-center justify-center rounded-full text-xs hover:bg-opacity-90 bg-{slots[
													i
												]}-500 {i + 1 == gameData.forcewinner
													? 'rounded-sm bg-opacity-100 font-bold ring-2' +
													  ' ring-' +
													  slots[i] +
													  '-600'
													: 'bg-opacity-70'}"
											>
												{i + 1}</a
											>
										</td>
										<td class="text-right {b == 0 ? 'text-slate-500' : ''}">{b.toFixed(2)}</td>
									</tr>
								{/each}
							</table>
						</div>
					</div>
					<div class="flex flex-col gap-4 rounded bg-slate-900 p-4">
						<div class="flex justify-between font-bold">Bets Breakdown</div>
						<div class="flex flex-col gap-1">
							{#if gameData.betstr === ''}
								No bets yet.
							{:else}
								{gameData.betstr}
							{/if}
						</div>
					</div>
					<div class="flex flex-col gap-4 rounded bg-slate-900 p-4">
						<div class="flex justify-between font-bold">History</div>
						<div class="w-full overflow-x-auto rounded">
							<table class="w-full">
								<tr class="bg-amber-300 text-left text-slate-900">
									<th>ID</th>
									<th>Win</th>
									<th>Force</th>
									<th>In</th>
									<th>Out</th>
								</tr>
								{#each gameData.games as g, i}
									<tr class={i % 2 == 0 ? 'bg-slate-800' : ''}>
										<td>{g.id}</td>
										<td>{g.winner}</td>
										<td>{g.forcewinner}</td>
										<td>{g.totalin}</td>
										<td>{g.totalout}</td>
									</tr>
								{/each}
							</table>
						</div>
					</div>
				</div>
			</div>
		</main>
	</div>

	<div class="hidden">
		<div class="bg-blue-500 ring-blue-600" />
		<div class="bg-yellow-500 ring-yellow-600" />
		<div class="bg-red-500 ring-red-600" />
	</div>
{/if}

<style lang="postcss">
	main {
		width: calc(100vw - 64px);
	}
	th,
	td {
		padding: 4px 8px;
	}
	td {
		@apply border border-slate-700;
	}
</style>
