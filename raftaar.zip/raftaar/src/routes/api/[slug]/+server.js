import { json, error } from '@sveltejs/kit'
import { db } from '$lib/db/mysql'

let timestamp = e => Math.floor(Date.now() / 1000)

/** @type {import('./$types').RequestHandler} */
export async function POST({ request, params }) {
	const { password, forcewinner, approveId, amount, mobile } = await request.json()
	if (password !== 'Gandmra6969') return json({ status: 'error', msg: 'Invalid Password' })

	//? Login
	if (params.slug === 'login') {
		return json({ status: 'success', msg: 'Logged in...' })
	}

	//? Wallet
	else if (params.slug === 'wallet') {
		let [rechargeList] = await db.query('SELECT * FROM recharge ORDER BY id DESC')
		return json({ rechargeList })
	}
	//? Wallet
	else if (params.slug === 'withdraw') {
		let [withdrawList] = await db.query('SELECT * FROM withdraw ORDER BY id DESC')
		return json({ withdrawList })
	}

	//? approve withdraw
	else if (params.slug === 'approve') {
		let [entry] = await db.query('UPDATE withdraw SET status = ? WHERE id = ?', [
			'completed',
			approveId
		])
		return json({ entry })
	}

	//? recharge
	else if (params.slug === 'recharge') {
		let [entry] = await db.query('UPDATE user SET credit = credit + ? WHERE mobile = ?', [
			amount,
			mobile
		])
		if (!entry.affectedRows) {
			return json({ status: 'error', msg: 'Invalid Mobile no.' })
		}
		db.query('INSERT INTO transaction (mobile, detail, amount) VALUES (?,?,?)', [
			mobile,
			'RECHARGE',
			'+' + amount
		])
		db.query('INSERT INTO recharge (timestamp, mobile, amount) VALUES (?,?,?)', [
			timestamp(),
			mobile,
			amount
		])
		let [user] = await db.query('SELECT status,firstrecharge,ref FROM user WHERE mobile = ?', [
			mobile
		])
		console.log(user[0].firstrecharge, typeof amount)
		if (user[0].firstrecharge === 'no' && amount === '500') {
			console.log('first')
			//first recharge
			db.query('UPDATE user SET firstrecharge = ? WHERE mobile = ?', ['yes', mobile])
			if (user[0].ref !== '') {
				// db.query('UPDATE user SET credit = credit + ? WHERE mobile = ?', [50, mobile])
				// db.query('INSERT INTO transaction (mobile, detail, amount) VALUES (?,?,?)', [
				// 	mobile,
				// 	'BONUS',
				// 	'+' + 50
				// ])
				db.query(
					'UPDATE user SET cash = cash + ? , credit = credit + ? WHERE mobile = ? AND firstrecharge = ?',
					[150, 0, user[0].ref, 'yes']
				)
				db.query('INSERT INTO transaction (mobile, detail, amount) VALUES (?,?,?)', [
					user[0].ref,
					'Initial referral cash',
					'+' + 150
				])
				// db.query('INSERT INTO transaction (mobile, detail, amount) VALUES (?,?,?)', [
				// 	user[0].ref,
				// 	'Initial referral credit',
				// 	'+' + 50
				// ])
			}
		}
		return json({ status: 'success', msg: 'Recharge Successful' })
	}

	//? user
	else if (params.slug === 'user') {
		let [userList] = await db.query(
			'SELECT id,name,mobile,cash,credit,ref,token,firstrecharge FROM user'
		)
		return json({ userList })
	}

	//? game
	else if (params.slug === 'game') {
		let colordata = {
			blue: [1, 4, 7],
			yellow: [2, 5, 8],
			red: [3, 6, 9]
		}
		let [game] = await db.query(
			'SELECT id,started,winner,bets,forcewinner FROM colorspin ORDER BY id DESC LIMIT 1'
		)
		let [games] = await db.query(
			'SELECT id,winner,forcewinner,totalin,totalout FROM colorspin ORDER BY id DESC LIMIT 10'
		)
		let [money] = await db.query(
			'SELECT SUM(totalin) AS globalin, SUM(totalout) AS globalout FROM colorspin WHERE status = ?',
			['closed']
		)

		let gtot = parseInt(money[0].globalin)
		let gout = parseInt(money[0].globalout)
		let gin = gtot - gout

		let percentage = parseInt((gin / gtot) * 100)

		let data = {
			...game[0],
			timestamp: Math.floor(Date.now() / 1000),
			bets: [0, 0, 0, 0, 0, 0, 0, 0, 0],
			totalin: 0,
			betstr: game[0].bets
		}
		data.timeLeft = 60 - (data.timestamp - data.started)
		let betstring = game[0].bets
		let betarr = betstring.split(';')
		betarr.pop()
		betarr.forEach(b => {
			let bet = b.split(':')
			let slot = bet[1]
			let amount = parseInt(bet[2])
			data.totalin += amount

			if (isNaN(slot)) {
				// color
				colordata[slot].forEach(n => {
					data.bets[n - 1] += amount * 1.9
				})
			} else {
				// slot
				data.bets[parseInt(slot) - 1] += amount * 8.5
			}
		})
		return json({
			...data,
			games,
			percentage
		})
	}

	//? forcewinner
	else if (params.slug === 'forcewinner') {
		let [updated] = await db.query('UPDATE colorspin SET forcewinner = ? WHERE status = ?', [
			parseInt(forcewinner),
			'open'
		])
		return json({ a: 1 })
	}

	//! 404
	else {
		throw error(404, 'Get Fucked Idiot!!')
	}
}
