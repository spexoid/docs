import { writable } from 'svelte/store'
import { browser } from '$app/environment'

export const password = writable((browser && localStorage.password) || 0)
password.subscribe(val => browser && (localStorage.password = val))

export const status = writable(0)
