const BROWSER = false;
const DEV = false;
export {
  BROWSER as B,
  DEV as D
};
