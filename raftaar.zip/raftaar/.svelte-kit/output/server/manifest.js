export const manifest = {
	appDir: "_app",
	appPath: "_app",
	assets: new Set(["favicon.png"]),
	mimeTypes: {".png":"image/png"},
	_: {
		client: {"start":"_app/immutable/entry/start.fc4c6290.js","app":"_app/immutable/entry/app.7649634b.js","imports":["_app/immutable/entry/start.fc4c6290.js","_app/immutable/chunks/index.b4e35c71.js","_app/immutable/chunks/singletons.7dbdf205.js","_app/immutable/chunks/index.447e724e.js","_app/immutable/entry/app.7649634b.js","_app/immutable/chunks/index.b4e35c71.js"],"stylesheets":[],"fonts":[]},
		nodes: [
			() => import('./nodes/0.js'),
			() => import('./nodes/1.js'),
			() => import('./nodes/2.js')
		],
		routes: [
			{
				id: "/",
				pattern: /^\/$/,
				params: [],
				page: { layouts: [0,], errors: [1,], leaf: 2 },
				endpoint: null
			},
			{
				id: "/api/[slug]",
				pattern: /^\/api\/([^/]+?)\/?$/,
				params: [{"name":"slug","optional":false,"rest":false,"chained":false}],
				page: null,
				endpoint: () => import('./entries/endpoints/api/_slug_/_server.js')
			}
		],
		matchers: async () => {
			
			return {  };
		}
	}
};
