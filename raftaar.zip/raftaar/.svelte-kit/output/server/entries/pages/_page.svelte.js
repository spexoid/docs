import { c as create_ssr_component, a as subscribe } from "../../chunks/index3.js";
import { w as writable } from "../../chunks/index2.js";
import { B as BROWSER } from "../../chunks/prod-ssr.js";
const browser = BROWSER;
const password = writable(0);
password.subscribe((val) => browser);
writable(0);
const _page_svelte_svelte_type_style_lang = "";
const css = {
  code: "main.svelte-1cdbdax{width:calc(100vw - 64px)}th.svelte-1cdbdax,td.svelte-1cdbdax{padding:4px 8px}td.svelte-1cdbdax{border-width:1px;--tw-border-opacity:1;border-color:rgb(51 65 85 / var(--tw-border-opacity))}",
  map: null
};
const Page = create_ssr_component(($$result, $$props, $$bindings, slots$1) => {
  let $password, $$unsubscribe_password;
  $$unsubscribe_password = subscribe(password, (value) => $password = value);
  let interval = [];
  function emptyInterval() {
    interval.forEach((i) => {
      clearInterval(i);
    });
  }
  let screen = {
    list: [
      {
        name: "home",
        active: 1,
        icon: ` <path stroke-linecap="round" stroke-linejoin="round" d="M2.25 12l8.954-8.955c.44-.439 1.152-.439 1.591 0L21.75 12M4.5 9.75v10.125c0 .621.504 1.125 1.125 1.125H9.75v-4.875c0-.621.504-1.125 1.125-1.125h2.25c.621 0 1.125.504 1.125 1.125V21h4.125c.621 0 1.125-.504 1.125-1.125V9.75M8.25 21h8.25"></path>`
      },
      {
        name: "wallet",
        active: 0,
        icon: `<path d="M21 9C21 8.40326 20.7629 7.83097 20.341 7.40901C19.919 6.98705 19.3467 6.75 18.75 6.75H15C15 7.54565 14.6839 8.30871 14.1213 8.87132C13.5587 9.43393 12.7956 9.75 12 9.75C11.2044 9.75 10.4413 9.43393 9.87868 8.87132C9.31607 8.30871 9 7.54565 9 6.75H5.25C4.65326 6.75 4.08097 6.98705 3.65901 7.40901C3.23705 7.83097 3 8.40326 3 9M21 9V18C21 18.5967 20.7629 19.169 20.341 19.591C19.919 20.0129 19.3467 20.25 18.75 20.25H5.25C4.65326 20.25 4.08097 20.0129 3.65901 19.591C3.23705 19.169 3 18.5967 3 18V9M21 9V6C21 5.40326 20.7629 4.83097 20.341 4.40901C19.919 3.98705 19.3467 3.75 18.75 3.75H5.25C4.65326 3.75 4.08097 3.98705 3.65901 4.40901C3.23705 4.83097 3 5.40326 3 6V9" stroke-linecap="round" stroke-linejoin="round"/> <path d="M15 12L9 18M9 18H13.5M9 18V13.5"stroke-linecap="round" stroke-linejoin="round"/>`
      },
      {
        name: "withdraw",
        active: 0,
        icon: `<path d="M21 9C21 8.40326 20.7629 7.83097 20.341 7.40901C19.919 6.98705 19.3467 6.75 18.75 6.75H15C15 7.54565 14.6839 8.30871 14.1213 8.87132C13.5587 9.43393 12.7956 9.75 12 9.75C11.2044 9.75 10.4413 9.43393 9.87868 8.87132C9.31607 8.30871 9 7.54565 9 6.75H5.25C4.65326 6.75 4.08097 6.98705 3.65901 7.40901C3.23705 7.83097 3 8.40326 3 9M21 9V18C21 18.5967 20.7629 19.169 20.341 19.591C19.919 20.0129 19.3467 20.25 18.75 20.25H5.25C4.65326 20.25 4.08097 20.0129 3.65901 19.591C3.23705 19.169 3 18.5967 3 18V9M21 9V6C21 5.40326 20.7629 4.83097 20.341 4.40901C19.919 3.98705 19.3467 3.75 18.75 3.75H5.25C4.65326 3.75 4.08097 3.98705 3.65901 4.40901C3.23705 4.83097 3 5.40326 3 6V9" stroke-linecap="round" stroke-linejoin="round"/><path d="M9 18L15 12M15 12H10.5M15 12V16.5" stroke-linejoin="round"/>`
      },
      {
        name: "user",
        active: 0,
        icon: `<path stroke-linecap="round" stroke-linejoin="round" d="M18 18.72a9.094 9.094 0 003.741-.479 3 3 0 00-4.682-2.72m.94 3.198l.001.031c0 .225-.012.447-.037.666A11.944 11.944 0 0112 21c-2.17 0-4.207-.576-5.963-1.584A6.062 6.062 0 016 18.719m12 0a5.971 5.971 0 00-.941-3.197m0 0A5.995 5.995 0 0012 12.75a5.995 5.995 0 00-5.058 2.772m0 0a3 3 0 00-4.681 2.72 8.986 8.986 0 003.74.477m.94-3.197a5.971 5.971 0 00-.94 3.197M15 6.75a3 3 0 11-6 0 3 3 0 016 0zm6 3a2.25 2.25 0 11-4.5 0 2.25 2.25 0 014.5 0zm-13.5 0a2.25 2.25 0 11-4.5 0 2.25 2.25 0 014.5 0z"></path>`
      },
      {
        name: "game",
        active: 0,
        icon: `<path stroke-linecap="round" stroke-linejoin="round" d="M14.25 6.087c0-.355.186-.676.401-.959.221-.29.349-.634.349-1.003 0-1.036-1.007-1.875-2.25-1.875s-2.25.84-2.25 1.875c0 .369.128.713.349 1.003.215.283.401.604.401.959v0a.64.64 0 01-.657.643 48.39 48.39 0 01-4.163-.3c.186 1.613.293 3.25.315 4.907a.656.656 0 01-.658.663v0c-.355 0-.676-.186-.959-.401a1.647 1.647 0 00-1.003-.349c-1.036 0-1.875 1.007-1.875 2.25s.84 2.25 1.875 2.25c.369 0 .713-.128 1.003-.349.283-.215.604-.401.959-.401v0c.31 0 .555.26.532.57a48.039 48.039 0 01-.642 5.056c1.518.19 3.058.309 4.616.354a.64.64 0 00.657-.643v0c0-.355-.186-.676-.401-.959a1.647 1.647 0 01-.349-1.003c0-1.035 1.008-1.875 2.25-1.875 1.243 0 2.25.84 2.25 1.875 0 .369-.128.713-.349 1.003-.215.283-.4.604-.4.959v0c0 .333.277.599.61.58a48.1 48.1 0 005.427-.63 48.05 48.05 0 00.582-4.717.532.532 0 00-.533-.57v0c-.355 0-.676.186-.959.401-.29.221-.634.349-1.003.349-1.035 0-1.875-1.007-1.875-2.25s.84-2.25 1.875-2.25c.37 0 .713.128 1.003.349.283.215.604.401.96.401v0a.656.656 0 00.658-.663 48.422 48.422 0 00-.37-5.36c-1.886.342-3.81.574-5.766.689a.578.578 0 01-.61-.58v0z"></path>`
      }
    ],
    switch(name) {
      emptyInterval();
      screen.list.forEach((s, i) => {
        screen.list[i].active = s.name === name ? 1 : 0;
      });
      this.callback[name]();
    },
    callback: {
      home: (e) => {
        console.log("home");
        screen.callback.user();
        screen.callback.withdraw();
        screen.callback.wallet();
        screen.callback.game();
      },
      wallet: (e) => {
        console.log("wallet");
        fetch("/api/wallet", {
          method: "POST",
          headers: { "content-type": "application/json" },
          body: JSON.stringify({ password: $password })
        }).then((res) => res.json()).then((data) => {
          rechargeList = data.rechargeList;
          rechargeAmount = 0;
        });
      },
      withdraw: (e) => {
        console.log("withdraw");
        fetch("/api/withdraw", {
          method: "POST",
          headers: { "content-type": "application/json" },
          body: JSON.stringify({ password: $password })
        }).then((res) => res.json()).then((data) => {
          withdrawList = data.withdrawList;
          withdrawRequest = 0;
          withdrawAmount = 0;
        });
      },
      user: (e) => {
        console.log("user");
        fetch("/api/user", {
          method: "POST",
          headers: { "content-type": "application/json" },
          body: JSON.stringify({ password: $password })
        }).then((res) => res.json()).then((data) => {
          userList = data.userList;
          cash = 0;
          credit = 0;
        });
      },
      game: (e) => {
        console.log("game");
        function refreshGameData() {
          fetch("/api/game", {
            method: "POST",
            headers: { "content-type": "application/json" },
            body: JSON.stringify({ password: $password })
          }).then((res) => res.json()).then((data) => {
          });
        }
        refreshGameData();
        let gameInterval = setInterval(
          (e2) => {
            refreshGameData();
          },
          500
        );
        interval.push(gameInterval);
      }
    }
  };
  let withdrawList = [];
  let withdrawRequest = 0;
  let withdrawAmount = 0;
  let rechargeList = [];
  let rechargeAmount = 0;
  let userList = [];
  let cash = 0;
  let credit = 0;
  $$result.css.add(css);
  screen.list.filter((s) => s.active)[0].name;
  {
    withdrawList.forEach((w) => {
      w.status === "pending" && withdrawRequest++;
      withdrawAmount += w.amount * 0.95;
    });
  }
  {
    rechargeList.forEach((r) => {
      rechargeAmount += r.amount;
    });
  }
  {
    userList.forEach((u) => {
      if (![98, 1, 2].includes(u.id)) {
        cash += u.cash;
        credit += u.credit;
      }
    });
  }
  $$unsubscribe_password();
  return `${``}`;
});
export {
  Page as default
};
