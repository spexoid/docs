

export const index = 2;
export const component = async () => (await import('../entries/pages/_page.svelte.js')).default;
export const imports = ["_app/immutable/nodes/2.ebc3643f.js","_app/immutable/chunks/index.b4e35c71.js","_app/immutable/chunks/index.447e724e.js"];
export const stylesheets = ["_app/immutable/assets/2.7ddd1008.css"];
export const fonts = [];
