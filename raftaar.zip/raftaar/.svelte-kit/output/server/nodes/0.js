

export const index = 0;
export const component = async () => (await import('../entries/pages/_layout.svelte.js')).default;
export const imports = ["_app/immutable/nodes/0.1c29891d.js","_app/immutable/chunks/index.b4e35c71.js"];
export const stylesheets = ["_app/immutable/assets/0.7d093e37.css"];
export const fonts = [];
