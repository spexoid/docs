import * as universal from "../../../../src/routes/api/[slug]/+page.js";
export { universal };