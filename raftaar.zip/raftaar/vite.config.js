import { sveltekit } from '@sveltejs/kit/vite'
import { defineConfig } from 'vite'
import * as path from 'path'

export default defineConfig({
	resolve: {
		alias: {
			'@comp': path.resolve(__dirname, './src/components'),
			'@data': path.resolve(__dirname, './src/data'),
			'@store': path.resolve(__dirname, './src/stores')
		}
	},
	plugins: [sveltekit()],
	server: {
		port: 7002,
		strictPort: false
	}
})
